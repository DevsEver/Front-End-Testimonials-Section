// owl-carousel
	$(document).ready(function(){
	  $(".testimonial-carousel").owlCarousel({
		  items:3,
		  autolay:false,
		  nav:false,
		  loop:true,
		  dots:true
		  
	  });
	});